import OpenAI, { toFile } from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

function json(res, status, body) {
  res.status(status).setHeader("Content-Type", "application/json");
  return res.end(JSON.stringify(body));
}

function dataUrlToBuffer(dataUrl) {
  const match = /^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/.exec(dataUrl || "");
  if (!match) throw new Error("Invalid image data. Please upload a JPG, PNG, WEBP, or GIF image.");
  return {
    mime: match[1],
    buffer: Buffer.from(match[2], "base64"),
  };
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return json(res, 405, { error: "Method not allowed. Use POST." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return json(res, 500, {
      error: "OPENAI_API_KEY is not configured on the server.",
    });
  }

  try {
    const { image, effect, composition, mood, size } = req.body || {};

    if (!image) {
      return json(res, 400, { error: "Upload Picture A first." });
    }

    const allowedSizes = new Set([
      "1024x1024",
      "1024x1536",
      "1536x1024",
    ]);

    const outputSize = allowedSizes.has(size) ? size : "1024x1536";

    const { mime, buffer } = dataUrlToBuffer(image);
    const extension =
      mime === "image/jpeg" ? "jpg" :
      mime === "image/webp" ? "webp" :
      mime === "image/gif" ? "gif" : "png";

    const prompt = [
      "Edit the supplied source photograph into a polished, photorealistic fashion editorial image.",
      "Preserve the person's identity, natural facial features, body proportions, skin tone, and recognizable appearance.",
      "Do not add nudity or sexually explicit content.",
      "Keep clothing coverage appropriate for a mainstream fashion magazine.",
      `Editorial direction: ${effect || "Dark Luxury"}.`,
      `Composition: ${composition || "Three-quarter editorial"}.`,
      `Mood and styling: ${mood || "Cinematic warm"}.`,
      "Use professional studio or cinematic lighting, realistic skin texture, natural anatomy, refined wardrobe styling, and high-end magazine photography.",
      "Avoid distorted hands, extra limbs, warped facial features, plastic skin, or artificial-looking anatomy.",
    ].join("\n");

    const sourceFile = await toFile(buffer, `source.${extension}`, {
      type: mime,
    });

    const result = await client.images.edit({
      model: "gpt-image-1",
      image: sourceFile,
      prompt,
      size: outputSize,
      quality: "medium",
      input_fidelity: "high",
      n: 1,
    });

    const b64 = result?.data?.[0]?.b64_json;

    if (!b64) {
      throw new Error("The image provider returned no image.");
    }

    return json(res, 200, {
      images: [`data:image/png;base64,${b64}`],
      count: 1,
      estimatedCost: null,
      balance: null,
    });
  } catch (error) {
    console.error("Generation error:", error);

    const message =
      error?.error?.message ||
      error?.message ||
      "Image generation failed.";

    return json(res, 500, { error: message });
  }
}
